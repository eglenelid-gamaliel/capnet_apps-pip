default_app_config = 'django_drf_filepond.apps.DjangoDrfFilepondConfig'
