from django.apps import AppConfig


class PwaConfig(AppConfig):
    name = 'pwa'
